# -*- coding: utf-8 -*-
"""
Student Do: Trading Log.

This script demonstrates how to perform basic analysis of trading profits/losses
over the course of a month (20 business days).
"""

# @TODO: Initialize the metric variables




# @TODO: Initialize lists to hold profitable and unprofitable day profits/losses




# List of trading profits/losses
trading_pnl = [ -224,  352, 252, 354, -544,
                -650,   56, 123, -43,  254,
                 325, -123,  47, 321,  123,
                 133, -151, 613, 232, -311 ]

# @TODO: Iterate over each element of the list


    # @TODO: Cumulatively sum up the total and count


    # @TODO: Write logic to determine minimum and maximum values






    # @TODO: Write logic to determine profitable vs. unprofitable days





# @TODO: Calculate the average


# @TODO: Calculate count metrics


# @TODO: Calculate percentage metrics



# @TODO: Print out the summary statistics


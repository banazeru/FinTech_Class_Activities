# Risk Self-Research

Now that we have discussed what risk is in general, are there any particular types of risk that you find interesting?

## Instructions

Make a google search for types of risk. What kinds of risks did you find? Which of those pertain to *financial* risk? Of all of the types that you found, are there any that are fascinating to you, and why?


---

© 2020 Trilogy Education Services

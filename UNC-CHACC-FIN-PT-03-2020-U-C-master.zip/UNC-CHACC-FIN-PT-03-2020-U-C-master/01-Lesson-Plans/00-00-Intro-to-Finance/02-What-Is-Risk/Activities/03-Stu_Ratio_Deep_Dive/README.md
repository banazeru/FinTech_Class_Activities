# Ratio Deep Dive

Now that we have begun discussing different ways to compare investments, are there any methods that we haven't listed here?

## Instructions

In this unit, we described the Sharpe, Sortino, and Information Ratios. Are there any other ratios you can find that are useful for comparing across portfolios? What information do they allow us to compare different potential investments? When would you use them?


---

© 2020 Trilogy Education Services

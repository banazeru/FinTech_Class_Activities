# Inflation Reflection

Now that we have discussed the implications of inflation on the value of money, let's consider how that affects us on a personal level.

## Instructions

Consider your own personal investments, and your annual salary increases. Are you keeping up with, or beating inflation? How much larger would your annual increases need to be in order to avoid devaluation? If you're not currently employed, do research on the average entry salaries for the roles that you would like to take on. How much would those salaries need to increase each year to stay ahead of inflation?

---

© 2020 Trilogy Education Services

# Phone-a-Friend

In the first section of this module, we began exploring the definitions of value, money, and currency. These three concepts are often used interchangeably in colloquial use - how well do those around you know the differences?

## Instructions

As a conversation starter amongst friends or family, ask What *is* money? Do their answers differ from what you've learned in this unit? How do their life experiences alter their definition?


---

© 2020 Trilogy Education Services

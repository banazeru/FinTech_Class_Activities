# -*- coding: UTF-8 -*-
"""Set Operations."""

hero1 = {"smart", "rich", "armored", "martial_artist", "strong"}
hero2 = {"smart", "fast", "strong", "invulnerable", "antigravity"}

type(hero1)
type(hero2)

# Attributes for both heros (union)

# Attributes common to both heros (intersection)

# Attributes in hero1 that are not in hero2 (difference)

# Attributes in hero2 that are not in hero1 (difference)

# Attributes for hero1 or hero2 but not both (symmetric difference)

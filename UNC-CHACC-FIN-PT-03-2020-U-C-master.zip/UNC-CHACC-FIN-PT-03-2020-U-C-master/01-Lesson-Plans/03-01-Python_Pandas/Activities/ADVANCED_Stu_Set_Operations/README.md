# Set Operations

## Instructions

Use set operations in Python to answer each section in the unsolved file.

---

© 2019 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.

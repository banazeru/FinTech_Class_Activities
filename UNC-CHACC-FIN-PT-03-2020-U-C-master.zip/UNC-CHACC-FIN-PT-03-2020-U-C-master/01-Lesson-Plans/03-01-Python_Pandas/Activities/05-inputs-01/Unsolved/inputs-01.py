# Declare a variable `welcome_name` as an input with a string of "Welcome to the sandwich shop, what do I call you? ".


# Then print the string "Hello" concatenated with the variable `welcome_name`.


# Declare a variable `question_sandwich` as an input with a string of "Are you here for a sandwich?".


# If `question_sandwich` is equal to true declare a variable `food_prompt` as an input with a string of "What kind of sandwich would you like?".
# Then print a string of "Please wait 10 min for your " concatenated with the variable `food_prompt`.
# Else If `question_sandwich` is false, print a string of "If you don't want a sandwich what are you here for?!".
# Else print a string of "You did not write Yes or No!"


# Create a variable named cheer
cheer = "Python"

# Below strings can be used to add fun
cheer_symbol = "*\O/*"
cheer_symbol_2 = "ヘ( ^o^)ノ＼(^_^ )"

# Loop through string
for x in cheer:
    #Print each letter with a cheer
    print("Give me a " + x + "!")
    print(x + "!")

# Print excitement to screen
print("\nWhat does that spell?!")
print(cheer + "!\nWoohoo! Go " + cheer + "!")
print(cheer_symbol * 3)
print(cheer_symbol_2)
